#include <project.h>

#include <stdbool.h>
#include <stdint.h>

#include "is31fl3236.h"

static volatile bool tiltChanged;
CY_ISR(TiltChangeISR) {
    tiltChanged = true;
    
    TiltSideISR_ClearPending();
    TiltUpISR_ClearPending();
}

int main()
{
    CyGlobalIntEnable;
    
    // init uart
    UART_Start();
    UART_PutString("Tomato Tusk [__DATE__] Starting...\n");
    
    // setup tilt sensors
    tiltChanged = false;
    TiltSideISR_StartEx(TiltChangeISR);
    TiltUpISR_StartEx(TiltChangeISR);
    
    if(!is31fl3236_Start()) {
        UART_PutString("Failed to start LED controller\n");
    }

    for(;;)
    {
        //TODO debounce tilt changes (just wait XXXms to settle)
        if(tiltChanged) {
            UART_PutString("Tilt changed!");
            tiltChanged = false;
        }
    }
}
