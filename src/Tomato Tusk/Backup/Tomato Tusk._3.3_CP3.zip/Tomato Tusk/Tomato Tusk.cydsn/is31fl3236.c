#include "is31fl3236.h"


bool is31fl3236_Start(void) {
    //TODO configure stuff
    
    return false;
}
