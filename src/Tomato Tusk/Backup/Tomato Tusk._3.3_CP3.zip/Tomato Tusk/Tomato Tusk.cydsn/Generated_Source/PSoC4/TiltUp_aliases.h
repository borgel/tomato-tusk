/*******************************************************************************
* File Name: TiltUp.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_TiltUp_ALIASES_H) /* Pins TiltUp_ALIASES_H */
#define CY_PINS_TiltUp_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define TiltUp_0			(TiltUp__0__PC)
#define TiltUp_0_PS		(TiltUp__0__PS)
#define TiltUp_0_PC		(TiltUp__0__PC)
#define TiltUp_0_DR		(TiltUp__0__DR)
#define TiltUp_0_SHIFT	(TiltUp__0__SHIFT)
#define TiltUp_0_INTR	((uint16)((uint16)0x0003u << (TiltUp__0__SHIFT*2u)))

#define TiltUp_INTR_ALL	 ((uint16)(TiltUp_0_INTR))


#endif /* End Pins TiltUp_ALIASES_H */


/* [] END OF FILE */
