/*******************************************************************************
* File Name: TiltUpISR.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_TiltUpISR_H)
#define CY_ISR_TiltUpISR_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void TiltUpISR_Start(void);
void TiltUpISR_StartEx(cyisraddress address);
void TiltUpISR_Stop(void);

CY_ISR_PROTO(TiltUpISR_Interrupt);

void TiltUpISR_SetVector(cyisraddress address);
cyisraddress TiltUpISR_GetVector(void);

void TiltUpISR_SetPriority(uint8 priority);
uint8 TiltUpISR_GetPriority(void);

void TiltUpISR_Enable(void);
uint8 TiltUpISR_GetState(void);
void TiltUpISR_Disable(void);

void TiltUpISR_SetPending(void);
void TiltUpISR_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the TiltUpISR ISR. */
#define TiltUpISR_INTC_VECTOR            ((reg32 *) TiltUpISR__INTC_VECT)

/* Address of the TiltUpISR ISR priority. */
#define TiltUpISR_INTC_PRIOR             ((reg32 *) TiltUpISR__INTC_PRIOR_REG)

/* Priority of the TiltUpISR interrupt. */
#define TiltUpISR_INTC_PRIOR_NUMBER      TiltUpISR__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable TiltUpISR interrupt. */
#define TiltUpISR_INTC_SET_EN            ((reg32 *) TiltUpISR__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the TiltUpISR interrupt. */
#define TiltUpISR_INTC_CLR_EN            ((reg32 *) TiltUpISR__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the TiltUpISR interrupt state to pending. */
#define TiltUpISR_INTC_SET_PD            ((reg32 *) TiltUpISR__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the TiltUpISR interrupt. */
#define TiltUpISR_INTC_CLR_PD            ((reg32 *) TiltUpISR__INTC_CLR_PD_REG)



#endif /* CY_ISR_TiltUpISR_H */


/* [] END OF FILE */
