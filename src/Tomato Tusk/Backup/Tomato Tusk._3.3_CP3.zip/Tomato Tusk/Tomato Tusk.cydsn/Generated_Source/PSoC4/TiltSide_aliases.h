/*******************************************************************************
* File Name: TiltSide.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_TiltSide_ALIASES_H) /* Pins TiltSide_ALIASES_H */
#define CY_PINS_TiltSide_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define TiltSide_0			(TiltSide__0__PC)
#define TiltSide_0_PS		(TiltSide__0__PS)
#define TiltSide_0_PC		(TiltSide__0__PC)
#define TiltSide_0_DR		(TiltSide__0__DR)
#define TiltSide_0_SHIFT	(TiltSide__0__SHIFT)
#define TiltSide_0_INTR	((uint16)((uint16)0x0003u << (TiltSide__0__SHIFT*2u)))

#define TiltSide_INTR_ALL	 ((uint16)(TiltSide_0_INTR))


#endif /* End Pins TiltSide_ALIASES_H */


/* [] END OF FILE */
