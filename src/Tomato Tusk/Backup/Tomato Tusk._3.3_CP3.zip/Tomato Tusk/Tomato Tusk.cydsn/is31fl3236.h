#ifndef is31fl3236_H__
#define is31fl3236_H__
    
#include <stdbool.h>
    
bool is31fl3236_Start(void);
    
#endif//is31fl3236_H__